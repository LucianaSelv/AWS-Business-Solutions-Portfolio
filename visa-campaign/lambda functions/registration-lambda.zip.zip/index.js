const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { v4: uuidv4 } = require('uuid');

// Initialize clients
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

// Simple CPF validation (basic check - in production, use a more robust validation)
function isValidCPF(cpf) {
    // Remove non-digits
    cpf = cpf.replace(/\D/g, '');
    
    // Check length
    if (cpf.length !== 11) return false;
    
    // Check for all same digits
    if (/^(\d)\1+$/.test(cpf)) return false;
    
    // Basic validation is enough for demo
    return true;
}

// Simple Visa card validation (starts with 4 and has valid length)
function isValidVisaCard(cardNumber) {
    // Remove spaces
    cardNumber = cardNumber.replace(/\s/g, '');
    
    // Visa cards start with 4 and are 13-16 digits
    return /^4\d{12}(?:\d{3})?$/.test(cardNumber);
}

exports.handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const { name, email, cpf, cardNumber, cardExpiry } = body;
        
        // Input validation
        if (!name || !email || !cpf || !cardNumber || !cardExpiry) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'All fields are required' })
            };
        }
        
        // CPF validation
        if (!isValidCPF(cpf)) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'Invalid CPF format' })
            };
        }
        
        // Card validation
        if (!isValidVisaCard(cardNumber)) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'Invalid Visa card number' })
            };
        }
        
        // Check if CPF already exists
        const cpfClean = cpf.replace(/\D/g, '');
        const queryCommand = new QueryCommand({
            TableName: 'CampaignUsers',
            IndexName: 'CpfIndex',
            KeyConditionExpression: 'cpf = :cpf',
            ExpressionAttributeValues: {
                ':cpf': cpfClean
            }
        });
        const existingUser = await docClient.send(queryCommand);
        
        if (existingUser.Items && existingUser.Items.length > 0) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'This CPF is already registered' })
            };
        }
        
        // Generate userId
        const userId = uuidv4();
        
        // Store user data
        const putCommand = new PutCommand({
            TableName: 'CampaignUsers',
            Item: {
                userId,
                name,
                email,
                cpf: cpfClean,
                cardLastFour: cardNumber.slice(-4),
                cardExpiry,
                registrationDate: new Date().toISOString(),
                hasRedeemed: false
            }
        });
        await docClient.send(putCommand);
        
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                success: true,
                userId
            })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};