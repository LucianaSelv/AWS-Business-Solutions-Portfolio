// ecommerce-integration-lambda.js
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

// Initialize clients
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const { token } = body;
        
        if (!token) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'Token is required' })
            };
        }
        
        // Verify token exists and is valid
        const getTokenCommand = new GetCommand({
            TableName: 'CampaignTokens',
            Key: { token }
        });
        const tokenResult = await docClient.send(getTokenCommand);
        
        if (!tokenResult.Item) {
            return {
                statusCode: 404,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'Invalid token' })
            };
        }
        
        const tokenItem = tokenResult.Item;
        
        // Check if token is expired
        if (tokenItem.expiration < Math.floor(Date.now() / 1000)) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'Token expired' })
            };
        }
        
        // Check if token is already used
        if (tokenItem.isUsed) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'Token already used' })
            };
        }
        
        // Get user
        const userId = tokenItem.userId;
        const getUserCommand = new GetCommand({
            TableName: 'CampaignUsers',
            Key: { userId }
        });
        const userResult = await docClient.send(getUserCommand);
        
        if (!userResult.Item) {
            return {
                statusCode: 404,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'User not found' })
            };
        }
        
        const user = userResult.Item;
        
        // Check if user already redeemed
        if (user.hasRedeemed) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'User has already redeemed the offer' })
            };
        }
        
        // Mark token as used
        const updateTokenCommand = new UpdateCommand({
            TableName: 'CampaignTokens',
            Key: { token },
            UpdateExpression: 'SET isUsed = :isUsed',
            ExpressionAttributeValues: {
                ':isUsed': true
            }
        });
        await docClient.send(updateTokenCommand);
        
        // Mark user as having redeemed the offer
        const updateUserCommand = new UpdateCommand({
            TableName: 'CampaignUsers',
            Key: { userId },
            UpdateExpression: 'SET hasRedeemed = :hasRedeemed, redemptionDate = :redemptionDate',
            ExpressionAttributeValues: {
                ':hasRedeemed': true,
                ':redemptionDate': new Date().toISOString()
            }
        });
        await docClient.send(updateUserCommand);
        
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                success: true,
                message: 'Token verified and redeemed successfully',
                user: {
                    name: user.name,
                    email: user.email,
                    cardLastFour: user.cardLastFour
                }
            })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};