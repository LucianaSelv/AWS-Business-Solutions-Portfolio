// token-generation-lambda.js
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');
const { v4: uuidv4 } = require('uuid');

// Initialize clients
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const { userId } = body;
        
        if (!userId) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'userId is required' })
            };
        }
        
        // Verify user exists
        const getCommand = new GetCommand({
            TableName: 'CampaignUsers',
            Key: { userId }
        });
        const userResult = await docClient.send(getCommand);
        
        if (!userResult.Item) {
            return {
                statusCode: 404,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ error: 'User not found' })
            };
        }
        
        // Generate token
        const token = uuidv4();
        
        // Set expiration (24 hours from now)
        const expiration = Math.floor(Date.now() / 1000) + (24 * 60 * 60);
        
        // Store token
        const putCommand = new PutCommand({
            TableName: 'CampaignTokens',
            Item: {
                token,
                userId,
                created: new Date().toISOString(),
                expiration,
                isUsed: false
            }
        });
        await docClient.send(putCommand);
        
        // E-commerce redirect URL with token
        const redirectUrl = `https://your-ecommerce-site.com/visa-promotion?token=${token}`;
        
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                token,
                redirectUrl
            })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};